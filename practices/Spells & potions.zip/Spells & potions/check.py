import spells
print(spells.potion('Swelling Solution'))
#
# import spells
# print(spells.character('Minerva'))


# import spells
# print(spells.character('Minerva'))


import spells
print(spells.spell('Riddikulus'))

import spells
print(spells.character('Snape'))

import spells
print(spells.character('Albus'))

import spells
print(spells.calculate_age("23 April 1980"))


import spells
print(spells.spell('Riddikulus'))
